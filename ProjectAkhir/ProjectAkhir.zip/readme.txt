TUGAS AKHIR GRAFKOM
-------------------
version 3.5.2

tambahan:
- gerakin kucing W,A,S,D
- gerakin cahaya <arrow_key>

asumsi (azmi):
- spotlight dir selalu ke tengah

cacat:
- kucing gak bisa naik turun
- lampu gak bisa maju mundur
- shadow gak bisa pindah plane
- kalo lampu naik turun, shadow gak turun sejajar

---------
versi 3.6
---------
tambahan:
- ada burung
- gerakin troli T,F,G,H
- gerakin kalajengking I,J,K,L
- naik turun kucing 3,4
- naik turun troli 5,6
- naik turun kalajengking 7,8
- semua objek dan lingkungan dah di texture

asumsi (azmi):
- spotlight dir selalu ke tengah

cacat:
- kok shadow burungnya gak keluar wkwkwkwk
- lampu gak bisa maju mundur
- shadow gak bisa pindah plane
- kalo lampu naik turun, shadow gak turun sejajar

---------
versi 3.7
---------

------------
versi 8.4.6
------------
tambahan:
- lampu udah bisa mati : x dan z
- sebagian udah bisa wireframe: '.'
- toggle texture: ',' -- biar gak nge-lag

asumsi (azmi):
- spotlight dir selalu ke tengah

cacat:
- kok shadow burungnya gak keluar wkwkwkwk
- lampu gak bisa maju mundur
- shadow gak bisa pindah plane

------------
versi 8.4.7
------------
tambahan:
- lampu udah bisa mati : x dan z
- sebagian udah bisa wireframe: '.'
- toggle texture: ',' -- biar gak nge-lag

asumsi (azmi):
- spotlight dir selalu ke tengah

cacat:
- shadow burungnya akhirnya keluar tapi cuma 1 :")
- lampu gak bisa maju mundur
- shadow gak bisa pindah plane

------------
versi 8.5
++++++++++++
- dah bisa gerak



------------------
versi 8.6
------------------

- 1 kamera kucing
- 2 kamera kalajengking 
- 3 kamaer semut

// kalo cek kucing: gerakin dulu kucing sampe depan layar baru klik 1 
// (kucing kamera cuma bisa muter)
