#pragma once
#include <stdlib.h>
#include <glut.h>

// light 0 = depan

GLfloat light_depan_x = 0,
		light_depan_y = 0,
		light_depan_z = 8;

// cahaya depan
static void draw_light_depan(void)
{
	GLfloat light_depan_pos[4] = { light_depan_x, light_depan_y, light_depan_z, 1.0 };
	static GLfloat lightdir[3] = { 0.0, 0.0, 0.0 };

	glEnable(GL_LIGHT0);
	glPushMatrix();

	glLightfv(GL_LIGHT0, GL_POSITION, light_depan_pos);
	glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, lightdir);

	glPopMatrix();
}

// gambar lampu
static void draw_lamp_depan(void)
{
	glPushMatrix();
	glTranslatef(light_depan_x, light_depan_y, light_depan_z);
	glutSolidSphere(0.6, 10, 10);
	glPopMatrix();
}

static void draw_lamp_ataskanan()
{
	GLfloat diffuse1[] = { 1.0, 0.0, 0.0, 1.0 };
	GLfloat ambient0[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat specular0[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat light0_pos[] = { 8.0, 8.0, -0.0, 1.0 };

	glEnable(GL_LIGHT1);
	glLightfv(GL_LIGHT1, GL_POSITION, light0_pos);
	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient0);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse1);
	glLightfv(GL_LIGHT1, GL_SPECULAR, specular0);

    glPushMatrix();
	glTranslatef(8.0,8.0,0.0);
	glutSolidSphere(0.6, 10, 10);
	glPopMatrix();
}

static void draw_lamp_ataskiri()
{
	GLfloat diffuse2[] = { 1.0, 0.0, 1.0, 1.0 };
	GLfloat ambient0[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat specular0[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat light0_pos[] = { -8.0, 8.0, -0.0, 1.0 };

	glEnable(GL_LIGHT2);
	glLightfv(GL_LIGHT2, GL_POSITION, light0_pos);
	glLightfv(GL_LIGHT2, GL_AMBIENT, ambient0);
	glLightfv(GL_LIGHT2, GL_DIFFUSE, diffuse2);
	glLightfv(GL_LIGHT2, GL_SPECULAR, specular0);

    glPushMatrix();
	glTranslatef(-8.0,8.0,0.0);
	glutSolidSphere(0.6, 10, 10);
	glPopMatrix();
}

static void draw_lamp_atas()
{
	GLfloat diffuse3[] = { 0.0, 1.0, 0.0, 1.0 };
	GLfloat ambient0[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat specular0[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat light0_pos[] = { -0.0, 8.0, -0.0, 1.0 };

	glEnable(GL_LIGHT3);
	glLightfv(GL_LIGHT3, GL_POSITION, light0_pos);
	glLightfv(GL_LIGHT3, GL_AMBIENT, ambient0);
	glLightfv(GL_LIGHT3, GL_DIFFUSE, diffuse3);
	glLightfv(GL_LIGHT3, GL_SPECULAR, specular0);

    glPushMatrix();
	glTranslatef(0.0,8.0,0.0);
	glutSolidSphere(0.6, 10, 10);
	glPopMatrix();
}
