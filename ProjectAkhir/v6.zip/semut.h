#pragma once
#include "treestruct.h"


GLfloat semut_pos_x = 2.5,
semut_pos_y = -5,
semut_pos_z = 0;

treenode torso_semut_node, head_semut_node, foot_semut1_node, foot_semut2_node, foot_semut3_node, foot_semut4_node;

void headsemut_draw()
{
	glPushMatrix();
	//material_color(0.5, 0.0, 0.0);
	glutSolidSphere(head_height / 4, 10, 10);
	glPopMatrix();
}

// buat structure
void init_semut()
{
  	// torsokalajengking = kotak
	glLoadIdentity();
	glTranslatef(5, -0.5 * torso_height ,  torso_height / 2);
	glGetFloatv(GL_MODELVIEW_MATRIX, torso_semut_node.m);
	torso_semut_node.f = torsoKalajengking_draw;
	torso_semut_node.sibling = NULL;
	torso_semut_node.child = &head_semut_node;

	//headkalajengking = cone
	glLoadIdentity();
	glTranslatef(0.0, 0.0, torso_height/4 + head_height/2);
	glGetFloatv(GL_MODELVIEW_MATRIX, head_semut_node.m);
	head_semut_node.f = headsemut_draw;
	head_semut_node.sibling = &foot_semut1_node;
	head_semut_node.child = NULL;



	//kaki
	footKalajengking_quad = gluNewQuadric();

	//kaki depan kanan kalajengking
	gluQuadricDrawStyle(footKalajengking_quad, GLU_FILL);
	glLoadIdentity();
	glTranslatef(0.5, tail_rad - 0.5, tail_height / 2 + tail_height / 4 - 1);
	glRotatef(90, 1.0, 1.0, 0.0);
	glGetFloatv(GL_MODELVIEW_MATRIX, foot_semut1_node.m);
	foot_semut1_node.f = footKalajengking_draw;
	foot_semut1_node.sibling = &foot_semut2_node;
	foot_semut1_node.child = NULL;

	//kaki kanan belakang kalajengking
	gluQuadricDrawStyle(footKalajengking_quad, GLU_FILL);
	glLoadIdentity();
	glTranslatef(0.5, tail_rad - 0.5, tail_height / 2 + tail_height / 4 - 2.5);
	glRotatef(90, 1.0, 1.0, 0.0);
	glGetFloatv(GL_MODELVIEW_MATRIX, foot_semut2_node.m);
	foot_semut2_node.f = footKalajengking_draw;
	foot_semut2_node.sibling = &foot_semut3_node;
	foot_semut2_node.child = NULL;

	//kaki kiri depan kalajengking
	gluQuadricDrawStyle(footKalajengking_quad, GLU_FILL);
	glLoadIdentity();
	glTranslatef(-0.5, tail_rad - 0.5, tail_height / 2 + tail_height / 4 - 1);
	glRotatef(-90, 0.0, 1.0, 0.0);
	glRotatef(45, 1.0, 0.0, 0.0);
	glGetFloatv(GL_MODELVIEW_MATRIX, foot_semut3_node.m);
	foot_semut3_node.f = footKalajengking_draw;
	foot_semut3_node.sibling = &foot_semut4_node;
	foot_semut3_node.child = NULL;

	//kaki kiri belakang
	gluQuadricDrawStyle(footKalajengking_quad, GLU_FILL);
	glLoadIdentity();
	glTranslatef(-0.5, tail_rad - 0.5, tail_height / 2 + tail_height / 4 - 2.5);
	glRotatef(-90, 0.0, 1.0, 0.0);
	glRotatef(45, 1.0, 0.0, 0.0);
	glGetFloatv(GL_MODELVIEW_MATRIX, foot_semut4_node.m);
	foot_semut4_node.f = footKalajengking_draw;
	foot_semut4_node.sibling = NULL;
	foot_semut4_node.child = NULL;



	glLoadIdentity();
}

void draw_semut(bool shadow)
{
	glPushMatrix();
	if(shadow == false){
		glTranslatef(semut_pos_x, semut_pos_y, semut_pos_z);
	}
	traverse(&torso_semut_node);
	glPopMatrix();
}


