
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <glut.h>

#include "cat.h"
#include "troli.h"
#include "kalajengking.h"
#include "semut.h"
#include "texture.h"
#include "lighting.h"
#include "Bird.h"

#ifndef M_PI
#define M_PI 3.14159265
#endif

// menyimpan gambar shadow
static GLfloat catshadow[4][4];
static GLfloat catshadow2[4][4];
static GLfloat catshadow3[4][4];
static GLfloat catshadow4[4][4];

static GLfloat trolishadow[4][4];
static GLfloat trolishadow2[4][4];
static GLfloat trolishadow3[4][4];
static GLfloat trolishadow4[4][4];

static GLfloat kalajengkingshadow[4][4];
static GLfloat kalajengkingshadow2[4][4];
static GLfloat kalajengkingshadow3[4][4];
static GLfloat kalajengkingshadow4[4][4];

static GLfloat semutshadow[4][4];
static GLfloat semutshadow2[4][4];
static GLfloat semutshadow3[4][4];
static GLfloat semutshadow4[4][4];

static GLfloat birdshadow[4][4];
static GLfloat birdshadow2[4][4];
static GLfloat birdshadow3[4][4];
static GLfloat birdshadow4[4][4];

static float obs[3]={0.0,0.0,10.0};
static float dir[3];
static float v=0.0;
static float alpha=-90.0;
static float beta=90.0;
int lampu;
//camera parameter
GLfloat eyex = 0.0, eyey = 0.0, eyez =30.0,
centerx = 0.0, centery = 0.0, centerz = 0.0,
upx = 0.0, upy = 1.0, upz = 0.0;

// viewport
int SetupViewport(int cx, int cy)
{
	glViewport(0, 0, cx, cy);
	return 1;
}

// prespective
int SetupPerspectiveViewing(GLdouble aspect_ratio)
{
	gluPerspective(65.0f, aspect_ratio, 10.0f, -10.0f);
	return 1;
}

// viewing
int SetupViewingTransform()
{
	gluLookAt(eyex, eyey, eyez, centerx, centery, centerz, upx, upy, upz);
	return 1;
}

static void calcposobs(void) //calculate viewer position
{
  dir[0]=sin(alpha*M_PI/180.0);
  dir[1]=cos(alpha*M_PI/180.0)*sin(beta*M_PI/180.0);
  dir[2]=cos(beta*M_PI/180.0);

  obs[0]+=v*dir[0];
  obs[1]+=v*dir[1];
  obs[2]+=v*dir[2];
}

// resize
void OnResizeWindow(int cx, int cy)
{
	GLdouble aspect_ratio;
	if (0 >= cx || 0 >= cy) return;
	SetupViewport(cx, cy);
	aspect_ratio = (GLdouble)cx / (GLdouble)cy;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	SetupPerspectiveViewing(aspect_ratio);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	SetupViewingTransform();
}

// draw room
void draw_room()
{

	GLuint tex;

	glEnable(GL_TEXTURE_2D);

	// texture lantai
	tex = LoadTextureRAW("kucing.raw", true);
	glBindTexture(GL_TEXTURE_2D, tex);

	/* Floor */
	glBegin(GL_POLYGON);
	glNormal3f(0.0, 1.0, 0.0);
	glTexCoord2f(0.0, 0.0);
	glVertex3f(-10, -10, -10);
	glTexCoord2f(1.0, 0.0);
	glVertex3f(10, -10, -10);
	glTexCoord2f(1.0, 1.0);
	glVertex3f(10, -10, 10);
	glTexCoord2f(0.0, 1.0);
	glVertex3f(-10, -10, 10);
	glEnd();

	// texture atap
	tex = LoadTextureRAW("kucing.raw", true);
	glBindTexture(GL_TEXTURE_2D, tex);

	/* Ceiling */
	glBegin(GL_POLYGON);
	glNormal3f(0.0, -1.0, 0.0);
	glTexCoord2f(0.0, 0.0);
	glVertex3f(-10, 10, -10);
	glTexCoord2f(1.0, 0.0);
	glVertex3f(10, 10, -10);
	glTexCoord2f(1.0, 1.0);
	glVertex3f(10, 10, 10);
	glTexCoord2f(0.0, 1.0);
	glVertex3f(-10, 10, 10);
	glEnd();

	// texture tembok
	tex = LoadTextureRAW("kucing.raw", true);
	glBindTexture(GL_TEXTURE_2D, tex);


	/* Walls */
	glBegin(GL_POLYGON);
	glNormal3f(0.0, 0.0, 1.0);
	glTexCoord2f(0.0, 0.0);
	glVertex3f(-10, -10, -10);
	glTexCoord2f(1.0, 0.0);
	glVertex3f(10, -10, -10);
	glTexCoord2f(1.0, 1.0);
	glVertex3f(10, 10, -10);
	glTexCoord2f(0.0, 1.0);
	glVertex3f(-10, 10, -10);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, tex);

	glBegin(GL_POLYGON);
	glNormal3f(-1.0, 0.0, 0.0);
	glTexCoord2f(1.0, 1.0);
	glVertex3f(10, 10, 10);
	glTexCoord2f(0.0, 1.0);
	glVertex3f(10, -10, 10);
	glTexCoord2f(0.0, 0.0);
	glVertex3f(10, -10, -10);
	glTexCoord2f(1.0, 0.0);
	glVertex3f(10, 10, -10);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, tex);

	glBegin(GL_POLYGON);
	glNormal3f(1.0, 0.0, 0.0);
	glTexCoord2f(1.0, 1.0);
	glVertex3f(-10, 10, 10);
	glTexCoord2f(0.0, 1.0);
	glVertex3f(-10, -10, 10);
	glTexCoord2f(0.0, 0.0);
	glVertex3f(-10, -10, -10);
	glTexCoord2f(1.0, 0.0);
	glVertex3f(-10, 10, -10);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, 0);
}

// pilih plane shadow untuk cat
void update_shadow_cat()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 0 };
	GLfloat v1[3] = { 0,-10, 1 };
	GLfloat v2[3] = { 1,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { light_depan_x - cat_pos_x, light_depan_y - cat_pos_y, light_depan_z - cat_pos_z, 1 };

	shadowmatrix(catshadow, plane, light_sementara_depan);
}

void update_shadow_burung()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0, -10, 0 };
	GLfloat v1[3] = { 0, -10, 1 };
	GLfloat v2[3] = { 1, -10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { light_depan_x - bird_pos_x, light_depan_y - bird_pos_y, light_depan_z - bird_pos_z, 1 };

	shadowmatrix(birdshadow, plane, light_sementara_depan);
}

void update_shadow_troli()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 0 };
	GLfloat v1[3] = { 0,-10, 1 };
	GLfloat v2[3] = { 1,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { light_depan_x - troli_pos_x, light_depan_y - troli_pos_y, light_depan_z - troli_pos_z, 1 };

	shadowmatrix(trolishadow, plane, light_sementara_depan);
}

void update_shadow_kalajengking()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 0 };
	GLfloat v1[3] = { 0,-10, 1 };
	GLfloat v2[3] = { 1,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { light_depan_x - kalajengking_pos_x, light_depan_y - kalajengking_pos_y, light_depan_z - kalajengking_pos_z, 1 };

	shadowmatrix(kalajengkingshadow, plane, light_sementara_depan);
}

void update_shadow_semut()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 0 };
	GLfloat v1[3] = { 0,-10, 1 };
	GLfloat v2[3] = { 1,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { light_depan_x - semut_pos_x, light_depan_y - semut_pos_y, light_depan_z - semut_pos_z, 1 };

	shadowmatrix(semutshadow, plane, light_sementara_depan);
}




void update_shadow_cat_bawah()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 1 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { 0 - cat_pos_x, 8 - cat_pos_y, 0 - cat_pos_z, 1 };

	shadowmatrix(catshadow2, plane, light_sementara_depan);
}
void update_shadow_burung_bawah()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0, -10, 1 };
	GLfloat v1[3] = { 10, -10, 1 };
	GLfloat v2[3] = { 10, -10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { 0 - bird_pos_x, 8 - bird_pos_y, 0 - bird_pos_z, 1 };

	shadowmatrix(birdshadow2, plane, light_sementara_depan);
}
void update_shadow_kalajengking_bawah()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 0 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { 0 - kalajengking_pos_x, 8 - kalajengking_pos_y, 0 - kalajengking_pos_z, 1 };

	shadowmatrix(kalajengkingshadow2, plane, light_sementara_depan);
}

void update_shadow_troli_bawah()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 0 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { 0 - troli_pos_x, 8 - troli_pos_y, 0 - troli_pos_z, 1 };

	shadowmatrix(trolishadow2, plane, light_sementara_depan);
}
void update_shadow_semut_bawah()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 0 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { 0 - semut_pos_x, 8 - semut_pos_y, 0 - semut_pos_z, 1 };

	shadowmatrix(semutshadow2, plane, light_sementara_depan);
}



void update_shadow_cat_bawah_kiri()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 1 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { (-8) - cat_pos_x, 8 - cat_pos_y, 0 - cat_pos_z, 1 };

	shadowmatrix(catshadow3, plane, light_sementara_depan);
}


void update_shadow_burung_bawah_kiri()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0, -10, 1 };
	GLfloat v1[3] = { 10, -10, 1 };
	GLfloat v2[3] = { 10, -10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { (-8) - bird_pos_x, 8 - bird_pos_y, 0 - bird_pos_z, 1 };

	shadowmatrix(birdshadow3, plane, light_sementara_depan);
}

void update_shadow_kalajengking_bawah_kiri()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 0 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { (-8) - kalajengking_pos_x, 8 - kalajengking_pos_y, 0 - kalajengking_pos_z, 1 };

	shadowmatrix(kalajengkingshadow3, plane, light_sementara_depan);
}

void update_shadow_troli_bawah_kiri()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 1 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { (-8) - cat_pos_x, 8 - cat_pos_y, 0 - cat_pos_z, 1 };

	shadowmatrix(trolishadow3, plane, light_sementara_depan);
}

void update_shadow_semut_bawah_kiri()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 1 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { (-8) - semut_pos_x, 8 - semut_pos_y, 0 - semut_pos_z, 1 };

	shadowmatrix(semutshadow3, plane, light_sementara_depan);
}

void update_shadow_cat_bawah_kanan()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 1 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { 8 - cat_pos_x, 8 - cat_pos_y, 0 - cat_pos_z, 1 };

	shadowmatrix(catshadow4, plane, light_sementara_depan);
}

void update_shadow_burung_bawah_kanan()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0, -10, 1 };
	GLfloat v1[3] = { 10, -10, 1 };
	GLfloat v2[3] = { 10, -10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { 8 - bird_pos_x, 8 - bird_pos_y, 0 - bird_pos_z, 1 };

	shadowmatrix(birdshadow4, plane, light_sementara_depan);
}

void update_shadow_kalajengking_bawah_kanan()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 0 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { (8) - kalajengking_pos_x, 8 - kalajengking_pos_y, 0 - kalajengking_pos_z, 1 };

	shadowmatrix(kalajengkingshadow4, plane, light_sementara_depan);
}

void update_shadow_troli_bawah_kanan()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 1 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { (8) - troli_pos_x, 8 - troli_pos_y, 0 - troli_pos_z, 1 };

	shadowmatrix(trolishadow4, plane, light_sementara_depan);
}

void update_shadow_semut_bawah_kanan()
{
	GLfloat plane[4];

	GLfloat v0[3] = { 0,-10, 1 };
	GLfloat v1[3] = { 10,-10, 1 };
	GLfloat v2[3] = { 10,-10, 0 };

	findplane(plane, v0, v1, v2);

	GLfloat light_sementara_depan[4] = { (8) - semut_pos_x, 8 - semut_pos_y, 0 - semut_pos_z, 1 };

	shadowmatrix(semutshadow4, plane, light_sementara_depan);
}



// gambar shadow
void draw_shadow_cat()
{
	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)catshadow);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_cat(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)catshadow2);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_cat(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
    glMultMatrixf((GLfloat *)catshadow3);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_cat(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
    glMultMatrixf((GLfloat *)catshadow4);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_cat(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();
}


void draw_shadow_semut()
{
	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)semutshadow);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_semut(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)semutshadow2);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_semut(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
    glMultMatrixf((GLfloat *)semutshadow3);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_semut(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
    glMultMatrixf((GLfloat *)semutshadow4);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_semut(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();
}



void draw_shadow_bird()
{
	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)birdshadow);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_semut(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)birdshadow2);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_semut(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)birdshadow3);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_semut(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)birdshadow4);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_semut(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();
}


void draw_shadow_troli()
{
	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)trolishadow);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_troli(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)trolishadow2);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_troli(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
    glMultMatrixf((GLfloat *)trolishadow3);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_troli(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
    glMultMatrixf((GLfloat *)trolishadow4);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_troli(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();
}

void draw_shadow_kalajengking()
{
	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)kalajengkingshadow);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_Kalajengking(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
	glMultMatrixf((GLfloat *)kalajengkingshadow2);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_Kalajengking(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
    glMultMatrixf((GLfloat *)kalajengkingshadow3);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_Kalajengking(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();

	// taro shadow di base
	glPushMatrix();
    glMultMatrixf((GLfloat *)kalajengkingshadow4);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	// gambar shadow objek ke plane
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.25, 0.25, 0.25);
	draw_Kalajengking(true);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	glPopMatrix();
}


void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_LIGHTING);
	glShadeModel(GL_SMOOTH);

	// gambar
	glPushMatrix();
	draw_room();
	draw_shadow_cat();
	draw_shadow_troli();
	draw_shadow_kalajengking();
	draw_shadow_semut();
	draw_shadow_bird();
    draw_cat(false);
    draw_troli(false);
    draw_semut(false);
    draw_Kalajengking(false);
	draw_bird(false);
	material_color(1, 1, 1);
	draw_lamp_depan();
	draw_lamp_ataskanan();
	draw_lamp_ataskiri();
	draw_lamp_atas();
	draw_light_depan();
	glPopMatrix();

	glutSwapBuffers();
}


// animation
static GLint angle = 100;
void animation()
{
	animate_cat(angle);
	animate_bird(angle);
	// kalo sewaktu-waktu mau pindah plane
	update_shadow_cat();
	update_shadow_troli();
	update_shadow_kalajengking();
	update_shadow_semut();
	update_shadow_burung();

    update_shadow_cat_bawah();
    update_shadow_kalajengking_bawah();
    update_shadow_troli_bawah();
    update_shadow_semut_bawah();
	update_shadow_burung_bawah();

    update_shadow_cat_bawah_kanan();
    update_shadow_kalajengking_bawah_kanan();
    update_shadow_troli_bawah_kanan();
    update_shadow_semut_bawah_kanan();
	update_shadow_burung_bawah_kanan();

    update_shadow_cat_bawah_kiri();
    update_shadow_kalajengking_bawah_kiri();
    update_shadow_troli_bawah_kiri();
    update_shadow_semut_bawah_kiri();
	update_shadow_burung_bawah_kiri();

    if (lampu == 18){
		glDisable(GL_LIGHT1);
	}
	if (lampu == 19){
		glDisable(GL_LIGHT2);
	}
	if (lampu == 20){
		glEnable(GL_LIGHT1);
	}
	if (lampu == 21){
		glEnable(GL_LIGHT2);
	}

	glutPostRedisplay();
}

// init func
void init(void)
{
	glEnable(GL_LIGHTING);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glShadeModel(GL_SMOOTH);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texture);

	init_cat();
	init_troli();
	init_kalajengking();
	init_semut();
	init_bird();
	update_shadow_cat();
}

// keyboard
void keyBoardHandler(unsigned char c, int x, int y) {

	switch (c) {
	case 'w':  // cat mundur
		cat_pos_z -= 0.2;
		break;

	case 'a':  // cat kiri
		cat_pos_x -= 0.2;
		break;

	case 's': // cat maju
		cat_pos_z += 0.2;
		break;

	case 'd': // cat kanan
		cat_pos_x += 0.2;
		break;
	
	case '3': //cat naek
		cat_pos_y += 0.2;
		break;

	case '4': //cat turun
		cat_pos_y -= 0.2;
		break;

	case 'g':  // troli mundur
		troli_pos_z -= 0.2;
		break;

	case 'f':  // troli kiri
		troli_pos_x -= 0.2;
		break;

	case 't': // troli maju
		troli_pos_z += 0.2;
		break;


	case 'h': // troli kanan
		troli_pos_x += 0.2;
		break;

	case '5': //troli naek
		troli_pos_y += 0.2;
		break;

	case '6': //troli turun
		troli_pos_y -= 0.2;
		break;
	
	case 'l': // kalajengking kanan
		kalajengking_pos_x += 0.2;
		break;

	case 'k':  // kalajengking mundur
		kalajengking_pos_z -= 0.2;
		break;

	case 'j':  // kalajengking kiri
		kalajengking_pos_x -= 0.2;
		break;

	case 'i': // kalajengking maju
		kalajengking_pos_z += 0.2;
		break;

	case '7': //kalajengking naek
		kalajengking_pos_y += 0.2;
		break;

	case '8': //kalajengking turun
		kalajengking_pos_y -= 0.2;
		break;

    case '1':
		obs[0] = cat_pos_y, obs[1] = cat_pos_z, obs[2]=cat_pos_x;

		break;
    case 'q':
        obs[0] = 0.0, obs[1] = 0.0, obs[2] = 0.0;

		break;
	default:
		break;
	case 'x':
        glDisable(GL_LIGHT2);
        break;
    case 'z':
        glDisable(GL_LIGHT1);
        break;
    case 'c':
        alpha-=2.0;
        break;
    case 'v':
        alpha+=2.0;
        break;
    case 'b':
       beta-=2.0;
        break;
    case 'n':
        beta+=2.0;
        break;

	}
    printf("%d %d %d",obs[0],obs[1],obs[2]);

}

// arrow
void specialKeyHandler(int key, int x, int y) {

	float fraction = 0.05f;

	switch (key) {
	case GLUT_KEY_LEFT: // cahaya kiri
		light_depan_x -= 0.2;
		break;
	case GLUT_KEY_RIGHT: // cahaya kanan
		light_depan_x += 0.2;
		break;
	case GLUT_KEY_UP: // cahaya atas
		light_depan_y += 0.2;
		break;
	case GLUT_KEY_DOWN: // cahaya bawah
		light_depan_y -= 0.2;
		break;
	default:
		break;
	}

}

void mainmenu(int id)
{
	if (id < 18 || id >= 100){
		angle = id;
	}
	else{
		lampu = id;
	}
}
/*
static void menuInit(void) {

	int createMenuCat, createMenu_subCat, createMenu_subKalajengking, createMenu_wall, createMenu_MatObj,createMenu_Texture;

	glutCreateMenu(mainmenu);
	glutAddSubMenu("Move_Cat", createMenu_subCat);
	glutAddSubMenu("Move_Scorpion", createMenu_subKalajengking);
	glutAddMenuEntry("Move_all", 100);
	glutAddMenuEntry("Diam", 101);
	glutAddSubMenu("Texture Control", createMenu_Texture);
	glutAddMenuEntry("Lampu 1 mati", 18);
	glutAddMenuEntry("Lampu 2 mati", 19);
	glutAddMenuEntry("Lampu 1 nyala", 20);
	glutAddMenuEntry("Lampu 2 nyala", 21);

	glutAttachMenu(GLUT_RIGHT_BUTTON);
}
*/
// main func
int main(int argc, char* argv[])
{
	int mode = GLUT_DOUBLE | GLUT_RGBA;

	glutInit(&argc, argv);
	glutInitDisplayMode(mode);
	glutInitWindowSize(600, 600);
	glutInitWindowPosition(300, 75);
	glutCreateWindow("Tugas Akhir");
    //menuInit();
	init();

	glutSpecialFunc(specialKeyHandler);
	glutKeyboardFunc(keyBoardHandler);
	glutDisplayFunc(display);
	glutReshapeFunc(OnResizeWindow);
	glutIdleFunc(animation);
	glutMainLoop();

	return 0;
}
